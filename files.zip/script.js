const navToggle = document.getElementById('navToggle');
  const primaryNav = document.getElementById('primaryNav');
  navToggle.addEventListener('click', () => {
    primaryNav.classList.toggle('open');
    navToggle.classList.toggle('active');
  });

  // Mobile: tap "Services" to expand dropdown instead of hover
  const servicesDropdown = document.getElementById('servicesDropdown');
  const servicesToggle = document.getElementById('servicesToggle');
  servicesToggle.addEventListener('click', (e) => {
    if (window.innerWidth <= 760) {
      e.preventDefault();
      servicesDropdown.classList.toggle('open');
    }
  });

  // Close mobile nav after clicking a link
  document.querySelectorAll('.primary-nav a').forEach(link => {
    link.addEventListener('click', () => {
      if (window.innerWidth <= 760 && link !== servicesToggle) {
        primaryNav.classList.remove('open');
      }
    });
  });
