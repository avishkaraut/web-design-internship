# MainCrafts — Task 2: Multi-Page Website

A 3-page responsive site built for the Full Stack Web Development Internship, Task 2.

## Pages
- `index.html` — Home (hero + services)
- `about.html` — About (company info, timeline)
- `contact.html` — Contact (validated form)

## Files
- `style.css` — shared styles (blueprint/architectural visual identity)
- `script.js` — mobile nav toggle + contact form validation

## Run it
Just open `index.html` in a browser — no build step needed.
