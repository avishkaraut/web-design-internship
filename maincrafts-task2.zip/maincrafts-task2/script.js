// MainCrafts — shared behavior

document.addEventListener('DOMContentLoaded', function () {
  // Mobile nav toggle
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var isOpen = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }
});

// Contact form validation
function validateForm() {
  var form = document.forms['contactForm'];
  var name = form['name'].value.trim();
  var email = form['email'].value.trim();
  var status = document.getElementById('formStatus');

  var nameField = form['name'];
  var emailField = form['email'];
  var nameMsg = document.getElementById('nameMsg');
  var emailMsg = document.getElementById('emailMsg');

  nameField.classList.remove('field-error');
  emailField.classList.remove('field-error');
  nameMsg.textContent = '';
  emailMsg.textContent = '';

  var hasError = false;

  if (name === '') {
    nameField.classList.add('field-error');
    nameMsg.textContent = 'Name is required.';
    hasError = true;
  }

  if (email === '') {
    emailField.classList.add('field-error');
    emailMsg.textContent = 'Email is required.';
    hasError = true;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    emailField.classList.add('field-error');
    emailMsg.textContent = 'Enter a valid email address.';
    hasError = true;
  }

  if (hasError) {
    alert('Name and Email must be filled out!');
    status.classList.remove('visible');
    return false;
  }

  status.textContent = 'Message received — sheet logged for A-03 / Contact. We reply within one business day.';
  status.classList.add('visible');
  form.reset();
  return false; // demo only — no backend wired up yet
}
